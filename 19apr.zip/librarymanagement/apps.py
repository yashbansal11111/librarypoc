from django.apps import AppConfig


class LibrarymanagementConfig(AppConfig):
    name = 'librarymanagement'
