import re
from django import forms
from librarymanagement.models import IssueBook, LibraryRegistration, Student


# class LibraryRegisterForm(forms.ModelForm):
#     email = forms.EmailField(label = ("E-mail Address"),required=True)
#     #password1 = forms.CharField(label = ("Password"),widget=forms.PasswordInput, required=True)
#     #password2 = forms.CharField(label = ("Password Confirmation"),
#     #                            widget=forms.PasswordInput,
#     #                            required=True
#     #                            )
#     class Meta:
#         model = Student
#         #fields = ['email','password1', 'password2']
#         fields = ['email']


class PasswordForm(forms.ModelForm):
    """This is Form class for Password Generation"""
    email_address = forms.EmailField(required=True,disabled=True)
    password1 = forms.CharField(label = ("Password"),widget=forms.PasswordInput, required=True)
    password2 = forms.CharField(label = ("Password Confirmation"),
                                widget=forms.PasswordInput,
                                required=True
                                )
    class Meta:
        """This is Meta class """
        model = LibraryRegistration
        fields = ['email_address','password1', 'password2']

    def __init__(self, instance):
        super().__init__()
        self.fields['email_address'].initial = instance

class LoginForm(forms.ModelForm):
    """This is Form class for Student Login"""
    username = forms.EmailField(label = ("Email-Address"),required = True)
    password1 = forms.CharField(label = ('Password'), widget = forms.PasswordInput, required=True)
    class Meta:
        """This is Meta class """
        model = LibraryRegistration
        fields = ['username', 'password1']


class IssueBookForm(forms.ModelForm):
    """This is Form class for Issuing Book to Students"""
    class Meta:
        """This is Meta class """
        model = IssueBook
        fields = ['select_book', 'select_no_of_weeks']
