import csv, io
from django.core.mail import EmailMessage
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib import messages
from django.views import View
from librarymanagement.models import LibraryRegistration, Student
from django.contrib.auth.decorators import permission_required
from librarymanagement.forms import LibraryRegisterForm, PasswordForm
from django.core.mail import BadHeaderError, send_mail
from django.http import HttpResponse

from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from .tokens import account_activation_token




# Create your views here.
@permission_required('admin.can_add_log_entry')
def uploadcsv(request):
    if request.method == 'GET':
        return render(request, 'librarymanagement/uploadcsv.html' )
    else:
        csv_file = request.FILES['file']
        if not csv_file.name.endswith('.csv'):
            return render(request, 'librarymanagement/uploadcsv.html',{'error':'This is not a csv file, Please try again.'} )
        else:
            data_set = csv_file.read().decode('UTF-8')
            io_string = io.StringIO(data_set)
            next(io_string)
            for column in csv.reader(io_string, delimiter='|', skipinitialspace=True):
                updated, created = Student.objects.update_or_create(
                    first_name = column[0],
                    last_name = column[1],
                    date_of_birth = column[2],
                    email = column[3],
                    phone = column[4]
                )
                #print(type(updated))
                print(updated.first_name,'+++++++++++++++')
                print(updated.pk,'*******************')
                updated.is_active = False 
                updated.save()
                #_, is a throwaway variable which we use to save the above code without actually calling save method
            
            domain = get_current_site(request).domain
            # link = reverse('activate', kwargs={'uidb64':uidb64, 'token':token})

            email_subject = 'University Library - Activate your Account'
            #Using render_to_string to render a template having a message and activation link in string form to send to email_body.
            email_body = render_to_string('librarymanagement/email_activation.html', {  
                'updated': updated,  
                'domain': domain,  
                'uid':urlsafe_base64_encode(force_bytes(updated.pk)),  
                'token':account_activation_token.make_token(updated),  
            })
            email_recipient = Student.objects.values('email')
            email_recipient_lst=[]
            for i in email_recipient:
                email_recipient_lst.append(i['email'])
            print(email_recipient,'.................')
            print(email_recipient_lst)
            send_email = EmailMessage(
                    email_subject,
                    email_body,
                    'noreply@librarian.com',
                    email_recipient_lst,
            )
            send_email.send(fail_silently=False)

            return HttpResponse('Upload Successfull, Emails are sent to the students whose emails are yet to be activated.')


def emailpage(request):
    if request.method == "GET":
        return render(request, 'librarymanagement/RegisterPage.html', {'form': LibraryRegisterForm()})
        
    else:
        # username = request.POST['username']
        # email = request.POST['email']
        # password = request.POST['password']

        # if not User.objects.filter(username=username).exists():
        #     if not User.objects.filter(email=email).exists():
        #         if len(password)<6:
        #             messages.error(request, 'Password Too Short')
        #             return render(request, 'librarymanagement/RegisterPage.html')

        #         user = User.objects.create_user(username=username, email=email)
        #         user.set_password(password)
        #         user.is_active = False
        #         user.save()
        #         messages.success(request, 'Account Successfully Created')
        #         return render(request, 'librarymanagement/RegisterPage.html')

        # username = request.POST['username']
        # email = request.POST['email']
        # password = request.POST.get('password')

        # user = Student.objects.create_user(username=username, email=email)
        # user.set_password(password)
        # user.is_active = False

        # user.save()
        # messages.success(request, 'Account successfully created')
        

        form = LibraryRegisterForm(request.POST)
        if form.is_valid():  
            subject = 'University Library - Generate your password'
            message = 'Please click the link below to generate your password -'
            from_email = 'librarian@gmail.com'
            to_email = request.POST.get('email','') #take email field or provide a blank default
            #print(type(to_email),'++++++++')
            #print(request.POST)
            #print(to_email,'*******')
            
            if subject and message and from_email and to_email:    
                try:
                    send_mail(subject, message, from_email, [to_email])
                except BadHeaderError:
                    return HttpResponse('Invalid header found.')
            return HttpResponse('An email has been sent to you. Please click the link in your email to generate you password.')
            
        else:
            return HttpResponse('Make sure all fields are entered and valid.')


def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = Student.objects.get(pk=uid)
        print(uid,'++++++++++++')
        print(user,'*************')
        print(uidb64,'------------')
    except(TypeError, ValueError, OverflowError, Student.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        #return HttpResponse('Email Activated Successfully! Create your password and register to the library portal')
        #return redirect('/generatepassword/<uidb64>')
        return redirect(passwordgeneration, uidb64 = uidb64)
        # return HttpResponse('Thank you for your email confirmation. Now you can login your account.')
    else:
        return HttpResponse('Activation link is invalid or expired! Either you have already clicked on the link & activated your Email or the link is expired.')


def passwordgeneration(request, uidb64):
    uid = force_str(urlsafe_base64_decode(uidb64))
    user = Student.objects.get(pk=uid)
    print(user,'++++++++++++')

    if request.method == 'GET':
    #     def get_initial(self):
    #         user = Student.objects.get(pk = uid)
    #         return {
    #             'email_id': user.email
    #         }  
        password_gen_form = PasswordForm() 
        return render(request, 'librarymanagement/password_generation.html', {'form':password_gen_form})
    else:
        pass

