
from email.policy import default
from mimetypes import init
from django import forms
from requests import request
from librarymanagement.models import Student, LibraryRegistration


class LibraryRegisterForm(forms.ModelForm):
    email = forms.EmailField(label = ("E-mail Address"),required=True)
    #password1 = forms.CharField(label = ("Password"),widget=forms.PasswordInput, required=True)
    #password2 = forms.CharField(label = ("Password Confirmation"),widget=forms.PasswordInput, required=True)
    class Meta:
        model = Student
        #fields = ['email','password1', 'password2']
        fields = ['email']


class PasswordForm(forms.ModelForm):
    
    user = Student.objects.get(pk=10)
    email_address = forms.EmailField(required=True,initial=user,disabled=True)
    password1 = forms.CharField(label = ("Password"),widget=forms.PasswordInput, required=True)
    password2 = forms.CharField(label = ("Password Confirmation"),widget=forms.PasswordInput, required=True)
    class Meta:
        model = LibraryRegistration
        fields = ['email_address','password1', 'password2']

    
    
        
        
