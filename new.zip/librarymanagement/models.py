from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from datetime import date
from django.contrib.auth.models import AbstractUser

class Student(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField(validators=[MaxValueValidator(limit_value=date.today)], default=None)
    email = models.EmailField(max_length=100, unique=True)
    phone = models.BigIntegerField(validators=[MaxValueValidator(9999999999), MinValueValidator(1000000000)], unique=True)
    is_active = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name','last_name', 'date_of_birth', 'email', 'phone']

    def __str__(self):
        return self.first_name+' '+self.last_name


class LibraryRegistration(AbstractUser):
    email_address = models.OneToOneField(Student, on_delete=models.CASCADE, null=True)
    password1 = models.CharField(max_length=32)
    password2 = models.CharField(max_length=32)
